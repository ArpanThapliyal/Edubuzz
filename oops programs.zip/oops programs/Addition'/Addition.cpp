#include<iostream>
using namespace std;
int main()
{
    int a,b,sum;

    cout<<"Enter first number ";
    cin>>a;
    cout<<"Enter second number ";
    cin>>b;

    cout<<endl;

    sum=a+b;
    cout<<"The sum of both the numbers is "<<sum;

    return 0;
}
