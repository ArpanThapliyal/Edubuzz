#include<iostream>
using namespace std;
int main()
{
    int a,b,div;

    cout<<"Enter first number ";
    cin>>a;
    cout<<"Enter second number ";
    cin>>b;

    div=a/b;

    cout<<"The division of both the numbers is "<<div;

    return 0;
}

