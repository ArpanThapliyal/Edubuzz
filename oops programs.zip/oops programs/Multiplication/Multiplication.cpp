#include<iostream>
using namespace std;
int main()
{
    int a,b,prod;

    cout<<"Enter first number ";
    cin>>a;
    cout<<"Enter second number ";
    cin>>b;

    prod=a*b;

    cout<<"The Product of both the numbers is "<<prod;

    return 0;
}

