#include<iostream>
using namespace std;
int main()
{
    int a,area;

    cout<<"Enter radius of circle ";
    cin>>a;

    area=3.14*a*a;

    cout<<"The area of circle is "<<area;

    return 0;
}


