#include<iostream>
using namespace std;
int main()
{
    int a,area;

    cout<<"Enter side of square ";
    cin>>a;

    area=a*a;

    cout<<"The area of square is "<<area;

    return 0;
}

