#include<iostream>
using namespace std;

int fact(int n){
 if (n>=1)
        return n*fact(n-1);
    else
        return 1;
}

int main(){

    int a,fac;

cout<<"Enter the no for which you want factorial ";
cin>>a;

cout<<"Factorial of "<<a<<" is "<<fact(a);

return 0;
}

