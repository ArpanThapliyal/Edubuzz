#include<iostream>
using namespace std;

int main()
{
    int a,sum=0;

    cout<<"Enter upto which no you want to find the sum ";
    cin>>a;

    for(int i=0;i<=a;i++)
    {
        sum=sum+i;
    }
    cout<<sum;
}
