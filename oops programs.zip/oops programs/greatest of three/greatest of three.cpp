#include<iostream>
using namespace std;
int main()
{
    int a,b,c;

    cout<<"Enter first number ";
    cin>>a;
    cout<<"Enter second number ";
    cin>>b;
    cout<<"Enter third number ";
    cin>>c;

    if(a>b && a>c){
        cout<<"First num is greater";
    }
    else if(b>a && b>c){
        cout<<"Second num is greater";
    }
    else if(c>a && c>b){
        cout<<"Third num is greater";
    }
    else{
        cout<<"Put another number ";
    }

    return 0;
}

