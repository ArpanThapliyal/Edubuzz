#include <iostream>
using namespace std;
int main() {
   int sea, c, n=6;
   int arr[] = { 12, 35, 69, 74, 165, 54};
   sea=165;
   for (c = 0; c < n; c++) {
      if (arr[c] == sea) {
         cout<<("%d is present at location %d.\n", sea, c+1);
         break;
      }
   }
   if (c == n)
      cout<<("%d isn't present in the array.\n", sea);
   return 0;
}
