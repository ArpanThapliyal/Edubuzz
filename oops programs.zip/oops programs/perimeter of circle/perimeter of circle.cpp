#include<iostream>
using namespace std;
int main()
{
    int a,per;

    cout<<"Enter radius of circle ";
    cin>>a;

    per=3.14*a*2;

    cout<<"The Perimeter of circle is "<<per;

    return 0;
}



