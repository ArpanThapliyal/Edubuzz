#include<iostream>
using namespace std;
int main()
{
    int a,Per;

    cout<<"Enter side of square ";
    cin>>a;

    Per=a*4;

    cout<<"The Perimeter of square is "<<Per;

    return 0;
}


