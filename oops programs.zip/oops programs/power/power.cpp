#include<iostream>
#include<cmath>
using namespace std;

int power(int n)
{
    float sqrt;
    cout<<"Enter number ";
    cin>>n;

    sqrt=pow(n,0.5);

    cout<<"The sqrt of number is "<<sqrt;
}

int main()
{
    int n;
    power(n);
    return 0;
}
