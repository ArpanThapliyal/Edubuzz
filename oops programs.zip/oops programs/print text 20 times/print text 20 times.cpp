#include<iostream>
#include<string>
using namespace std;

int main(){
string a;

a="Ritik garg";

for(int i=1;i<=20;i++)
{
    cout<<a<<endl;
}

return 0;
}


