#include <iostream>
using namespace std;
class Decimal_Number
{
protected:
int i=1,j=n,n,  binaryn=0;
public:
Decimal_Number()
{
cout<<" enter  Decimal  Number :";
cin>>n;
for(j=n;j>0;j=j/2)
{
binaryn=binaryn+(n%2)*i;
i=i*10;
n=n/2;
}
}
friend int show(Decimal_Number);
};
int show(Decimal_Number A)
{
cout<<"binary number ="<<A.binaryn<<endl;
}
int main()
{
Decimal_Number A;
show(A);
}
