#include<iostream>
using namespace std;
class Ritik
{
private:
int n,i;
public:
Ritik()
{
cout<<"Enter Number to Display reverse: ";
cin>>n;
}
friend void show(Ritik);
};
void show(Ritik r)
{
cout<<"The reverse the Entered number: ";
for(r.i=r.n;r.i>0;r.i=r.i/10)
{
cout<<r.i%10;
}
}
int main()
{
Ritik r;
show(r);
}
