#include<iostream>
using namespace std;
int main()
{
    int a,b,diff;

    cout<<"Enter first number ";
    cin>>a;
    cout<<"Enter second number ";
    cin>>b;

    diff=a-b;

    cout<<"The difference of both the numbers is "<<diff;

    return 0;
}
